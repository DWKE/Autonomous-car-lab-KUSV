Version 190614_1733

Initial backup


Next version changes
//1. Remove cluster color to intensity.
//- cluster.cpp
//void SetCloud ( ~ )
//
//2. Remove generateColor function
1. Add transformation bt tf
